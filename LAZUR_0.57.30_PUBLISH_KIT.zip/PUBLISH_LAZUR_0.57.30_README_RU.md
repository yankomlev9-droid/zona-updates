LAZUR 0.57.30 TEST. Публиковать только после проверки навигации кнопок внутри «Подробно» на телевизоре.
Загрузить только LAZUR_0.57.30_PUBLISH_KIT.zip в корень main репозитория yankomlev9-droid/zona-updates.
Workflow Publish LAZUR update создаст два отдельных файла: LAZUR_0.57.30_GITHUB_UPDATE_4_FILES.zip и LAZUR_0.57.30_RELEASE_SOURCE.zip.
Содержимое PUBLISH_KIT: оба архива, этот файл, заметки и SHA256SUMS.
