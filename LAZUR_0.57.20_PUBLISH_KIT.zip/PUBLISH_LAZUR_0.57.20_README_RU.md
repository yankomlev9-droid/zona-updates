# Публикация LAZUR 0.57.20

**Пока не публиковать — сначала тест переноса позиции на Kodi.**

Когда пользователь подтвердит тест: загрузить **только** `LAZUR_0.57.20_PUBLISH_KIT.zip` в корень репозитория `yankomlev9-droid/zona-updates` (ветка `main`) через GitHub Upload files → Commit changes.

Workflow `Publish LAZUR update` автоматически создаст `lazur-v0.57.20` и приложит два отдельных ZIP: программу и полные исходники. Версии Zona не затрагиваются.
