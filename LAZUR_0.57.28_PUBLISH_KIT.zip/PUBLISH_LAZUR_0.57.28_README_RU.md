LAZUR 0.57.28 TEST: сначала проверить на телевизоре.
Загрузить только LAZUR_0.57.28_PUBLISH_KIT.zip в корень main репозитория yankomlev9-droid/zona-updates.
GitHub workflow Publish LAZUR update создаст два отдельных файла: LAZUR_0.57.28_GITHUB_UPDATE_4_FILES.zip и LAZUR_0.57.28_RELEASE_SOURCE.zip.
Не публиковать до подтверждения всех окон LAZUR.
